package com.example.appservice.controller;

import com.example.appservice.model.AppOwner;
import com.example.appservice.service.AppOwnerService;
import jakarta.persistence.EntityManager;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/owners")
public class AppOwnerController {

    private final AppOwnerService appOwnerService;
    private final EntityManager entityManager;

    public AppOwnerController(AppOwnerService appOwnerService,
                              EntityManager entityManager) {
        this.appOwnerService = appOwnerService;
        this.entityManager = entityManager;
    }

    public static class OwnerAppDto {
        private Long id;
        private String name;
        private String type;
        private String genre;

        public OwnerAppDto() {}
        
        public OwnerAppDto(Long id, String name, String type, String genre) {
            this.id = id;
            this.name = name;
            this.type = type;
            this.genre = genre;
        }

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getType() { return type; }
        public void setType(String type) { this.type = type; }
        public String getGenre() { return genre; }
        public void setGenre(String genre) { this.genre = genre; }
    }

    @PostMapping("/add")
    public ResponseEntity<AppOwner> addOwner(@RequestBody AppOwner owner) {
        AppOwner savedOwner = appOwnerService.saveOwner(owner);
        return ResponseEntity.ok(savedOwner);
    }

    @GetMapping("/all")
    public ResponseEntity<List<AppOwner>> getAllOwners() {
        return ResponseEntity.ok(appOwnerService.getAllOwners());
    }

    @GetMapping("/list")
    public ResponseEntity<List<AppOwner>> getOwnersList() {
        return ResponseEntity.ok(appOwnerService.getAllOwners());
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginOwner(@RequestParam("userName") String userName,
                                        @RequestParam("password") String password) {
        AppOwner owner = appOwnerService.getOwnerByUsername(userName);
        if (owner != null && owner.getPassword().equals(password)) {
            return ResponseEntity.ok(userName);
        }
        return ResponseEntity.status(401).body("Invalid username or password");
    }

    @GetMapping("/{username}/apps")
    public ResponseEntity<List<OwnerAppDto>> getAppsByOwner(@PathVariable String username) {
        AppOwner owner = appOwnerService.getOwnerByUsername(username);

        if (owner == null) {
            return ResponseEntity.notFound().build();
        }

        String sql = """
            SELECT APP_ID, APP_NAME, APP_TYPE, GENRE
            FROM APP_DETAILS
            WHERE APP_OWNER_ID = :id
            """;

        @SuppressWarnings("unchecked")
        List<Object[]> rows = entityManager
                .createNativeQuery(sql)
                .setParameter("id", owner.getAppOwnerId())
                .getResultList();

        List<OwnerAppDto> apps = rows.stream()
                .map(r -> new OwnerAppDto(
                        r[0] == null ? null : ((Number) r[0]).longValue(),
                        r[1] == null ? null : r[1].toString(),
                        r[2] == null ? null : r[2].toString(),
                        r[3] == null ? null : r[3].toString()
                ))
                .collect(Collectors.toList());

        return ResponseEntity.ok(apps);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOwner(@PathVariable Long id) {
        try {
            appOwnerService.deleteOwner(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException ex) {
            return ResponseEntity.notFound().build();
        }
    }
}