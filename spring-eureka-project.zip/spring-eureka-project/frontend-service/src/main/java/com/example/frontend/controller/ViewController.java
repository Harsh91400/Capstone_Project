package com.example.frontend.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpMethod;
import java.util.List;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class ViewController {

    private final RestTemplate restTemplate;
    private final String backendBase;

    public ViewController(RestTemplate restTemplate, @Value("${backend.base.url}") String backendBase) {
        this.restTemplate = restTemplate;
        this.backendBase = backendBase;
    }

    @GetMapping({"/", "/index"})
    public String index(Model model) {
        try {
            ResponseEntity<List> resp = restTemplate.exchange(backendBase + "/apps", HttpMethod.GET, null, List.class);
            model.addAttribute("apps", resp.getBody());
        } catch(Exception e) {
            model.addAttribute("apps", List.of());
            model.addAttribute("error", "Cannot load apps: " + e.getMessage());
        }
        return "index";
    }

    @GetMapping("/apps/genre")
    public String appsByGenre(@RequestParam("genre") String genre, Model model) {
        try {
            ResponseEntity<List> resp = restTemplate.exchange(backendBase + "/apps/genre/" + genre, HttpMethod.GET, null, List.class);
            model.addAttribute("apps", resp.getBody());
        } catch(Exception e) {
            model.addAttribute("apps", List.of());
            model.addAttribute("error", "Cannot load apps by genre: " + e.getMessage());
        }
        return "index";
    }
    
    @GetMapping("/owners/{username}/apps")
    public String ownerApps(@PathVariable String username, Model model) {
        try {
            String url = backendBase + "/owners/" + username + "/apps";
            ResponseEntity<List> resp = restTemplate.exchange(
                    url, HttpMethod.GET, null, List.class
            );
            model.addAttribute("apps", resp.getBody());
        } catch (Exception e) {
            model.addAttribute("apps", List.of());
            model.addAttribute("error", "Cannot load your apps: " + e.getMessage());
        }
        model.addAttribute("owner", username);
        return "owner-apps";  // JSP name
    }
}
