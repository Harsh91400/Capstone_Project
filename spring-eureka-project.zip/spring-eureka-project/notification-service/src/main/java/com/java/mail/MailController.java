package com.java.mail;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/mail")
public class MailController {

    private final MailService mailService;

    public MailController(MailService mailService) {
        this.mailService = mailService;
    }

    
    @PostMapping("/user-activated")
    public ResponseEntity<String> sendUserActivatedMail(@RequestBody UserActivationMailRequest request) {

        System.out.println("=== /mail/user-activated HIT from app-service ===");
        System.out.println("email     = " + request.getEmail());
        System.out.println("firstName = " + request.getFirstName());
        System.out.println("userName  = " + request.getUserName());

        mailService.sendUserActivatedMail(request);

        System.out.println("=== MailService.sendUserActivatedMail() CALLED ===");

        return ResponseEntity.ok("Activation mail sent to user.");
    }
}
