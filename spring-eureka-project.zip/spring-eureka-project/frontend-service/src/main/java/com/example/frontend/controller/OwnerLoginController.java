package com.example.frontend.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;

@Controller
public class OwnerLoginController {

    private final RestTemplate restTemplate;

    @Value("${backend.base.url}")
    private String backend;

    public OwnerLoginController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @PostMapping("/owners/login")
    public String handleOwnerLogin(@RequestParam String username,
                                   @RequestParam String password,
                                   Model model) {

        try {
            String url = backend + "/owners/login";
            ResponseEntity<String> resp = restTemplate.postForEntity(
                    url + "?username=" + username + "&password=" + password,
                    null,
                    String.class
            );

            if (resp.getStatusCode().is2xxSuccessful()) {
                // login success then redirect to owner apps page
                return "redirect:/owners/" + username + "/apps";
            } else {
                model.addAttribute("error", "Invalid username or password");
                return "owner-login";
            }

        } catch (Exception e) {
            model.addAttribute("error", "Cannot login: " + e.getMessage());
            return "owner-login";
        }
    }
}
