package com.example.appservice.controller;

import com.example.appservice.model.Admin;

import com.example.appservice.model.User;
import com.example.appservice.model.UserActivationMailRequest;
import com.example.appservice.repository.AdminRepository;
import com.example.appservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import com.example.appservice.security.JwtUtil;
import java.util.HashMap;
import java.util.Map;

import java.util.Optional;

@RestController
@RequestMapping("/admins")
public class AdminController {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestTemplate restTemplate;
    
    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/add")
    public Admin addAdmin(@RequestBody Admin admin){
        admin.setAdminStatus("YES");
        return adminRepository.save(admin);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Admin payload) {
        try {
            System.out.println("=== [APP-SERVICE] Admin login hit ===");

            if (payload.getUserName() == null || payload.getPassword() == null) {
                return ResponseEntity.badRequest().body("MISSING_CREDENTIALS");
            }

            Optional<Admin> adminOpt = adminRepository.findByUserName(payload.getUserName());
            if (adminOpt.isEmpty()) {
                System.out.println("Admin not found in DB for username: " + payload.getUserName());
                return ResponseEntity.status(404).body("ADMIN_NOT_FOUND");
            }

            Admin admin = adminOpt.get();

            if (!payload.getPassword().equals(admin.getPassword())) {
                System.out.println("Wrong password for username: " + payload.getUserName());
                return ResponseEntity.status(401).body("WRONG_PASSWORD");
            }

            System.out.println("Admin login success for: " + payload.getUserName());

            // ✅ SUCCESS: generate JWT token for ROLE_ADMIN
            String token = jwtUtil.generateToken(admin.getUserName(), "ROLE_ADMIN");

            Map<String, Object> body = new HashMap<>();
            body.put("token", token);
            body.put("userName", admin.getUserName());
            body.put("role", "ADMIN");

            return ResponseEntity.ok(body);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500)
                    .body("ERROR: " + e.getMessage());
        }
    }



    @PostMapping("/users/{id}/activate")
    public ResponseEntity<String> activateUser(@PathVariable Long id) {

        System.out.println("=== [APP-SERVICE] activateUser hit, id = " + id);

        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("USER_NOT_FOUND"));

        System.out.println("Current user status: " + user.getStatus());

        user.setStatus("ACTIVE");
        userRepository.save(user);

        System.out.println("User status updated to ACTIVE for " + user.getEmail());

        UserActivationMailRequest req = new UserActivationMailRequest();
        req.setEmail(user.getEmail());
        req.setFirstName(user.getFirstName());
        req.setUserName(user.getUserName());

        String url = "http://localhost:8082/mail/user-activated";

        try {
            System.out.println("=== [APP-SERVICE] Calling notification-service: " + url);
            ResponseEntity<String> resp =
                    restTemplate.postForEntity(url, req, String.class);

            System.out.println("=== [APP-SERVICE] Mail request success. Response body: " + resp.getBody());

            return ResponseEntity.ok("USER ACTIVATED, MAIL SENT");
        } catch (Exception ex) {
            System.out.println("=== [APP-SERVICE] Error while calling notification-service ===");
            ex.printStackTrace();
            return ResponseEntity.ok("USER ACTIVATED, BUT MAIL FAILED: " + ex.getMessage());
        }
    }
}